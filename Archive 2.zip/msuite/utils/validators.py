"""Shared validation utilities and API response helpers."""
import frappe
from frappe.utils import getdate


def success_response(data: dict | list) -> dict:
    """Wraps data in standard success envelope."""
    return {"status": "success", "data": data}


def error_response(error_code: str, message: str) -> dict:
    """Returns standard error envelope."""
    return {"status": "error", "error_code": error_code, "message": message}


def require_customer_exists(customer: str) -> None:
    """Raises frappe.DoesNotExistError if customer not found."""
    if not frappe.db.exists("Customer", customer):
        frappe.throw(f"Customer {customer} not found", frappe.DoesNotExistError)


def require_permission(doctype: str, name: str | None = None, ptype: str = "read") -> None:
    """Validates current user has permission."""
    if name:
        if not frappe.has_permission(doctype, ptype, name):
            frappe.throw(f"No {ptype} permission for {doctype} {name}", frappe.PermissionError)
    else:
        if not frappe.has_permission(doctype, ptype):
            frappe.throw(f"No {ptype} permission for {doctype}", frappe.PermissionError)


def require_system_manager_or_msuite_manager() -> None:
    """Validates current user has System Manager or MSuite Manager role."""
    roles = frappe.get_roles()
    if "System Manager" not in roles and "MSuite Manager" not in roles:
        frappe.throw("Requires System Manager or MSuite Manager role", frappe.PermissionError)


def validate_date_string(date_str: str, field_name: str) -> None:
    """Validates date string is valid ISO format YYYY-MM-DD."""
    try:
        getdate(date_str)
    except Exception:
        frappe.throw(
            f"Invalid date format for {field_name}: {date_str}. Expected YYYY-MM-DD.",
            frappe.ValidationError,
        )


def validate_positive_float(value: float, field_name: str, allow_zero: bool = True) -> None:
    """Validates value is >= 0 (or > 0 if allow_zero=False)."""
    if allow_zero and value < 0:
        frappe.throw(f"{field_name} must be >= 0, got {value}", frappe.ValidationError)
    elif not allow_zero and value <= 0:
        frappe.throw(f"{field_name} must be > 0, got {value}", frappe.ValidationError)
