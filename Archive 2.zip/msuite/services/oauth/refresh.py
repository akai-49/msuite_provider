"""
Token refresh scheduler — proactively refreshes expiring tokens.

Runs hourly via hooks.py. For each Active Connected Account with
token_expiry within 24 hours:
  - If a refresher exists for the platform → refresh the token and push
    updated credentials to the client
  - If not refreshable (Meta user tokens) → send a notification to the
    admin 7 days before expiry

Called from: msuite.services.oauth.refresh_expiring_tokens (already
registered in __init__.py and hooks).
"""
import frappe
from frappe.utils import now, add_days, get_datetime

from msuite.constants import (
    ConnectedAccountStatus,
    TOKEN_REFRESH_BUFFER_DAYS,
    MSUITE_LOGGER_NAME,
)

logger = frappe.logger(MSUITE_LOGGER_NAME)

REFRESH_WINDOW_HOURS = 24
NOTIFICATION_WINDOW_DAYS = 7


def refresh_all_tokens() -> dict:
    """Hourly cron: refresh tokens approaching expiry.

    Returns summary of actions taken.
    """
    from msuite.services.oauth import _TOKEN_REFRESHERS

    cutoff = add_days(now(), 1)
    accounts = frappe.get_all(
        "MSuite Connected Account",
        filters=[
            ["status", "=", ConnectedAccountStatus.ACTIVE],
            ["token_expiry", "is", "set"],
            ["token_expiry", "<=", cutoff],
        ],
        fields=["name", "client", "platform", "account_id", "display_name", "token_expiry"],
    )

    summary = {"refreshed": 0, "notified": 0, "failed": 0}

    for account in accounts:
        refresher = _TOKEN_REFRESHERS.get(account.platform)

        if refresher:
            try:
                refresher(account.name)
                _push_refreshed_token(account)
                summary["refreshed"] += 1
                logger.info(f"Refreshed {account.platform} token for {account.display_name}")
            except Exception as e:
                summary["failed"] += 1
                logger.error(f"Token refresh failed for {account.name}: {e}")
        else:
            _notify_if_expiring_soon(account)
            summary["notified"] += 1

    frappe.db.commit()
    return summary


def _push_refreshed_token(account) -> None:
    """Push the refreshed token to the client instance."""
    from msuite.msuite_client.doctype.msuite_client.msuite_client import _PUSH_PAYLOAD_BUILDERS
    from msuite.services.oauth.base import push_account_to_client

    builder = _PUSH_PAYLOAD_BUILDERS.get(account.platform)
    if not builder:
        return

    ca = frappe.get_doc("MSuite Connected Account", account.name)
    token = ca.get_password("access_token") if ca.access_token else ""
    payload = builder(ca, token)
    if payload:
        push_account_to_client(account.client, account.platform, payload)


def _notify_if_expiring_soon(account) -> None:
    """Send a one-time notification when a non-refreshable token is near expiry.

    Checks if we've already notified for this account (via a cache key) to
    avoid spamming the admin every hour.
    """
    cache_key = f"msuite:token_notify:{account.name}"
    if frappe.cache.get_value(cache_key):
        return

    days_left = (get_datetime(account.token_expiry) - get_datetime(now())).days

    if days_left <= NOTIFICATION_WINDOW_DAYS:
        frappe.sendmail(
            recipients=_get_admin_emails(),
            subject=f"MSuite: {account.platform} token expiring in {days_left} days",
            message=(
                f"The {account.platform} token for <b>{account.display_name}</b> "
                f"(client: {account.client}) expires in {days_left} day(s).<br><br>"
                f"This platform does not support automatic refresh. "
                f"Please reconnect from the MSuite Client form or /connect page."
            ),
        )
        frappe.cache.set_value(cache_key, "1", expires_in_sec=86400 * 3)
        logger.info(f"Sent token expiry notification for {account.name} ({days_left} days left)")


def _get_admin_emails() -> list[str]:
    """Get email addresses of System Managers for notifications."""
    return frappe.get_all(
        "Has Role",
        filters={"role": "System Manager", "parenttype": "User"},
        pluck="parent",
        limit=5,
    )
